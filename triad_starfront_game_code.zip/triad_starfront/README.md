# Triad Starfront for Arcade Nest

A self-contained HTML5 Canvas space arena inspired by the broad three-faction space-shooter genre. It is an original single-player prototype with AI ships, asteroid mining, crystal collection, ship upgrades, faction stations, and a minimap. It is not a multiplayer clone of Starblast.io.

## Try it locally
Open `games/triad-starfront.html` in a modern browser.

## Add it to your Arcade Nest catalogue
Add an entry to the games array in `games.js` (adjust property names to match your existing catalogue):
```js
{
  id: "triad-starfront",
  title: "Triad Starfront",
  category: "Arcade",
  description: "Mine asteroids, upgrade your ship, and help one of three factions dominate the frontier.",
  status: "available",
  url: "games/triad-starfront.html",
  controls: "WASD / arrows to move, mouse to aim, click or Space to fire"
}
```
If your catalogue uses a different schema, copy the URL and title into the matching fields. Keep the `games` folder at the repository root beside `index.html`.

## Controls
- Move: WASD or arrow keys
- Aim: mouse
- Fire: click or Space
- Upgrade: use crystals from the HUD button
- Donate: fly near your own station, then press Donate crystals
- Mobile: use the on-screen fire and boost buttons; steer by dragging on the canvas (touch aim support is basic)

## Notes
This prototype has AI opponents, not online multiplayer. The game runs entirely in the browser and does not require a backend or external libraries.
